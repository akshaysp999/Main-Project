import os
from flask import *
from werkzeug.utils import secure_filename
from project.dbconnection import *
app=Flask (__name__)
app.secret_key="qweres"


@app.route("/")
def login():
    return render_template("login.html")
import functools
def login_required(func):
    @functools.wraps(func)
    def secure_function():
        if "lid" not in session:
            return'''<script>alert("please login");window.location="/"</script>'''
        return func()
    return secure_function


@app.route("/log",methods=['post'])
def log():
    uname=request.form['textfield']
    password=request.form['textfield2']
    qry="select * from login where username=%s and password=%s"
    val=(uname,password)
    res=selectonenew(qry,val)
    if res is None:
        return '''<script>alert("inavalid user");window.location="/"</script>'''
    elif res[3]=="admin":
        session['lid'] = res[0]

        return '''<script>alert("login success");window.location="/adminhome"</script>'''
    elif res[3]=="staff":
        session['lid']=res[0]
        return '''<script>alert("login success");window.location="/staffhome"</script>'''
    else:
        return '''<script>alert("inavalid");window.location="/"</script>'''



@app.route("/addcouse",methods=['post'])
@login_required
def addcouse():
    return render_template("add couse.html")



@app.route("/addcouse1",methods=['post'])
@login_required
def addcouse1():
    caurse=request.form['textfield']
    description=request.form['textfield2']
    qry="insert into course values(null,%s,%s)"
    value=(caurse,description)
    iud(qry,value)
    return '''<script>alert("success");window.location="/managecourse"</script>'''



@app.route("/deletecourse",methods=['get'])
@login_required
def deletecourse():
    id=request.args.get('id')
    qry="DELETE FROM course WHERE `cid`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/managecourse"</script>'''



@app.route("/editcourse",methods=['get'])
@login_required
def editcourse():
    id=request.args.get('id')
    session['cid']=id
    qry="SELECT * FROM `course` WHERE `cid`=%s"
    val=str(id)
    res=selectonenew(qry,val)
    return render_template("edit couse.html",val=res)



@app.route("/updatecourse",methods=['post'])
@login_required
def updatecourse():
    courseid=session['cid']
    cname= request.form['textfield']
    description=request.form['textfield2']
    qry="UPDATE course SET cname=%s,description=%s WHERE cid=%s"
    value=(cname,description,courseid)
    iud(qry,value)
    return '''<script>alert("updated");window.location="/managecourse"</script>'''



@app.route("/addexamdetails")
@login_required
def addexamdetails():
    qry="select * from course"
    res=selectall(qry)
    return render_template("view examdetailsadmin.html",val=res)



@app.route('/adminexam',methods=['post'])
@login_required
def adminexam():
    type=request.form['Submit2']
    if type=="ADD":
        qry = "SELECT * FROM `course`"
        res = selectall(qry)

        return render_template("add examdetails.html", val=res)
    else:
        course=request.form['select']
        print(course)
        qry="SELECT `examdetails`.*,`subject`.`subject`  FROM `subject`JOIN`examdetails` ON `subject`.`subjectid`=`examdetails`.`sid`  JOIN  `course` ON `course`.`cid`=`subject`.`causeid` WHERE `course`.`cid`=%s"
        val=(course)
        res=selectallnew(qry,val)
        print(res)
        qry = "SELECT * FROM `course`"
        res1 = selectall(qry)
        return render_template("view examdetailsadmin.html", val1=res,val=res1)



@app.route("/examdetails",methods=['post'])
@login_required
def examdetails():
    try:
         subjectid= request.form['select2']
         details=request.files['file']
         file=secure_filename(details.filename)
         date=request.form['date']
         details.save(os.path.join("static/examdetails",file))
         qry="INSERT INTO `examdetails` VALUES(NULL,%s,%s,%s)"
         value=(date,str(subjectid),file)
         iud(qry,value)
         return '''<script>alert("uploaded");window.location="/adminhome"</script>'''
    except Exception as e:
        return '''<script>alert("exam allocated");window.location="/addexamdetails"</script>'''




@app.route("/uploadquestionpapers",methods=['post'])
@login_required
def uploadquestionpapers():

    details = request.files['file']
    file = secure_filename(details.filename)
    details.save(os.path.join("static/questionpapers", file))
    qry = "INSERT INTO `questionpaper` VALUES(NULL,%s)"
    value = (file)
    iud(qry, value)
    return '''<script>alert("uploaded");window.location="/managequestionpapers"</script>'''




@app.route("/selectsub",methods=['get','post'])
@login_required
def selectsub():
    crse = request.form['crs']
    print(crse)

    # qry = "SELECT * FROM `subject` WHERE `causeid`=%s"
    qry="SELECT `subject`.*,`course`.* FROM `course` JOIN `subject` ON `subject`.`causeid`=`course`.`cid` WHERE `course`.`cname`=%s"
    val = str(crse)
    res = selectallnew(qry, val)
    print(res)
    lis = [0, 'select']
    for r in res:
        lis.append(r[0])
        lis.append(r[3])
    print(lis)
    resp = make_response(jsonify(lis))
    resp.status_code = 200
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp



@app.route("/addnote",methods=['post'])
@login_required
def addnote():
    qry="SELECT * FROM `subject`"
    res=selectall(qry)
    return render_template("add note.html",val=res)



@app.route("/addnote1",methods=['post'])
@login_required
def addnote1():
    subject= request.form['select']
    details = request.files['file']
    file = secure_filename(details.filename)
    details.save(os.path.join("static/notes", file))
    qry="INSERT INTO `notes` VALUES(NULL,%s,%s,curdate(),%s)"
    value=(file,str(session['lid']),subject)
    iud(qry, value)
    return '''<script>alert("uploaded");window.location="/managenotes"</script>'''



@app.route("/addquestonpapers",methods=['post'])
@login_required
def addquestionpapers():
    return render_template("add question papers.html")



@app.route("/addquestionsandanswer",methods=['post'])
@login_required
def addquestionsandanswers():
    lid=session['lid']
    qry = "SELECT examdetails.*,subject.subject FROM `examdetails`  JOIN `subject` ON `subject`.`subjectid`=`examdetails`.`sid` JOIN `subjectallocation` ON `subjectallocation`.`subjectid`=`subject`.`subjectid` WHERE `subjectallocation`.`loginid`=%s"
    value=str(lid)
    res = selectallnew(qry,value)
    return render_template("add questions and answers.html",val=res)



@app.route("/addquestionsandanswer1",methods=['post'])
@login_required
def addquestionsndanswer1():
    eid= request.form['select']
    questions = request.form['textarea']
    answers= request.form['textarea2']
    mark=request.form['textfield2']
    qry="INSERT INTO `questions`VALUES(NULL,%s,%s,%s,%s)"
    val=(str(eid),questions,answers,mark)
    iud(qry,val)
    return '''<script>alert("uploaded");window.location="/managequestionsandanswers"</script>'''



@app.route("/addstaff",methods=['post'])
@login_required
def addstaff():
    return render_template("add staff.html")



@app.route("/addstaff1",methods=['post'])
@login_required
def addstaff1():
    try:
        fname=request.form['textfield2']
        lname=request.form['textfield3']
        gender=request.form['radiobutton']
        dob=request.form['textfield']
        qualification=request.form.getlist('checkbox')
        qua=','.join(qualification)
        place=request.form['textfield5']
        phone=request.form['textfield6']
        email=request.form['textfield7']
        password=request.form['textfield8']
        qry="insert into login values(null,%s,%s,'staff')"
        value=(email,password)
        lid=iud(qry,value)
        qry1="insert into staff values(null,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val1=(fname,lname,dob,gender,place,qua,phone,email,str(lid))
        iud(qry1,val1)
        return '''<script>alert("registration success");window.location="/managestaff"</script>'''
    except Exception as e:
        return '''<script>alert("Duplicate Entry...plz try again");window.location="/managestaff"</script>'''



@app.route("/addstudents1",methods=['post'])
@login_required
def addstudents1():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    gender=request.form['radiobutton']
    dob=request.form['textfield3']
    course=request.form['select']
    semester=request.form['select2']
    place=request.form['textfield4']
    email=request.form['textfield5']
    phone=request.form['textfield6']
    password=request.form['textfield7']
    qry = "insert into login values(null,%s,%s,'student')"
    value = (email, password)
    lid = iud(qry, value)
    qry1 = "insert into student values(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    val1 = (str(lid),fname, lname, dob, gender, course, phone, email,place,semester)
    iud(qry1, val1)
    return '''<script>alert("registration success");window.location="/managestudents"</script>'''




@app.route("/addsubject",methods=['post'])
@login_required
def addsubject():
    qry="SELECT * FROM `course`"
    res= selectall(qry)
    return render_template("add subject.html",val=res)



@app.route("/addsubject1",methods=['post'])
@login_required
def addsubject1():
    courseid = request.form['select']
    subjectcode = request.form['textfield']
    subject=request.form['textfield2']
    semester=request.form['c']
    qry ="INSERT INTO `subject` VALUES(NULL,%s,%s,%s,%s)"
    value=(courseid,subjectcode,subject,semester)
    iud(qry, value)
    return '''<script>alert("success");window.location="/managesubjects"</script>'''



@app.route("/adminhome")
@login_required
def adminhome():
    return render_template("admin home.html")



@app.route("/allotsubjecttostaff")
@login_required
def allotsubjecttostaff():
    qry="SELECT * FROM `staff`"
    res=selectall(qry)
    qry1="SELECT * FROM `subject`"
    res1=selectall(qry1)
    return render_template("allot subject to staff.html",val=res,val1=res1)



@app.route("/allocation",methods=['post'])
@login_required
def allocation():
    try:
        subjectid=request.form['select2']
        staffid=request.form['select']
        qry="INSERT INTO `subjectallocation`VALUES(NULL,%s,%s)"
        value=(str(subjectid),str(staffid))
        iud(qry,value)
        return '''<script>alert("success");window.location="/adminhome"</script>'''
    except Exception as e:
        return '''<script>alert("allocated exam");window.location="/allotsubjecttostaff"</script>'''




@app.route("/chatwithstudents")
@login_required
def chatwithstudents():
     qry="select * from student"
     res=selectall(qry)
     return render_template("chat with students.html",val=res)



@app.route('/chat',methods=['GET','POST'])
@login_required
def chat():
    uid=request.args.get('uid')
    session['uidd']=uid
    qry=("select fname from student where loginid=%s")
    val=(str(uid))
    s1 = selectonenew(qry,val)
    print("ooooooooooo",s1)
    fid=session['lid']
    session['idd'] = uid
    qry=("select * from chat where (fid=%s and tid=%s) or (fid=%s and tid=%s) order by date asc")
    val=(str(uid),str(fid),str(fid),str(uid))
    s = selectallnew(qry,val)
    print(s1[0])
    print(uid)
    print(s)
    return render_template('chat.html',data=s,fname=s1[0],fr=str(uid))



@app.route('/chatsend',methods=['GET','POST'])
@login_required
def chatsend():
    btn=request.form['button']
    if (btn=="SEND"):
        fid=session["lid"]
        print(fid)
        tid=session['idd']
        session['uidd']=tid
        print(tid)
        msg=request.form['textarea']
        qry="insert into chat values(null,%s,%s,curdate(),%s)"
        val=(str(fid),str(tid),msg)
        iud(qry,val)
        return '''<script>window.location='/chatwithstudents'</script>'''
    else:
        return '''<script>window.location='/chatwithstudents'</script>'''




@app.route("/managecourse")
@login_required
def managecourse():
    qry="SELECT * FROM `course`"
    res = selectall(qry)
    return render_template("manage course.html",val=res)



@app.route("/manageexamdetails")
@login_required
def manageexamdetails():
    return render_template("manage examdetails.html")



@app.route("/managenotes")
@login_required
def managenotes():
    qry="SELECT `notes`.*,`subject`.`subject` FROM`notes` JOIN `subject` ON `notes`.`subjectid`=`subject`.`subjectid`"
    res=selectall(qry)
    return render_template("manage notes.html",val=res)



@app.route("/managequestionpapers")
@login_required
def managequestionpapers():
    qry="SELECT * FROM`questionpaper`"
    res=selectall(qry)
    return render_template("manage question papers.html",val=res)



@app.route("/managequestionsandanswers")
@login_required
def managequestionsandanswers():
    lid = session['lid']
    qry = "SELECT examdetails.*,subject.subject FROM `examdetails`  JOIN `subject` ON `subject`.`subjectid`=`examdetails`.`sid` JOIN `subjectallocation` ON `subjectallocation`.`subjectid`=`subject`.`subjectid` WHERE `subjectallocation`.`loginid`=%s"
    value = str(lid)
    res = selectallnew(qry, value)
    return render_template("manage questions and answers.html", val=res)



@app.route("/managequestionsandanswers1",methods=['post'])
@login_required
def managequestionsandanswers1():
    lid = session['lid']
    exam=request.form['select']
    print(exam)
    qry="SELECT * FROM `questions`WHERE `eid`=%s"
    value=(exam)
    res=selectallnew(qry, value)
    qry = "SELECT examdetails.*,subject.subject FROM `examdetails`  JOIN `subject` ON `subject`.`subjectid`=`examdetails`.`sid` JOIN `subjectallocation` ON `subjectallocation`.`subjectid`=`subject`.`subjectid` WHERE `subjectallocation`.`loginid`=%s"
    value = str(lid)
    ress = selectallnew(qry, value)
    return render_template("manage questions and answers.html", val1=res,val=ress)


@app.route("/deletequestions",methods=['get'])
@login_required
def deletequestios():
    id=request.args.get('id')
    qry="DELETE FROM `questions` WHERE `qid`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/managequestionsandanswers"</script>'''



@app.route("/deletequestionpapers",methods=['get'])
@login_required
def deletequestionpapers():
    id=request.args.get('id')
    print(id)
    qry="DELETE FROM `questionpaper` WHERE `qid`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/managequestionpapers"</script>'''



@app.route("/deletenotes")
@login_required
def deletenotes():
    id=request.args.get('id')
    print(id)
    qry="DELETE FROM `notes` WHERE `id`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/managenotes"</script>'''



@app.route("/deleteexamdetails",methods=['get'])
@login_required
def deleteexamdetails():
    id=request.args.get('id')
    print(id)
    qry="DELETE FROM `examdetails` WHERE `examid`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/addexamdetails"</script>'''




@app.route("/editquestions",methods=['get'])
@login_required
def editquestions():
    id = request.args.get('id')
    session['qid'] = id
    qry = "SELECT * FROM `questions` WHERE `qid`=%s"
    val = str(id)
    res = selectonenew(qry, val)
    return render_template("edit questions and answers.html",val=res)



@app.route("/updatequestions",methods=['post'])
@login_required
def updatequestions():
    id = session['qid']
    questions=request.form['textarea']
    answers=request.form['textarea2']
    mark=request.form['textfield2']
    qry = "UPDATE `questions` SET `question`=%s,`answer`=%s,`mark`=%s WHERE `qid`=%s"
    value = (questions, answers, mark, str(id))
    iud(qry, value)
    return '''<script>alert("updated");window.location="/managequestionsandanswers"</script>'''



@app.route("/managestaff")
@login_required
def managestaff():
    qry="SELECT * FROM `staff`"
    res=selectall(qry)
    return render_template("manage staff.html",val=res)



@app.route("/deletestaff",methods=['get'])
@login_required
def deletestaff():
    id=request.args.get('id')
    qry="DELETE FROM `staff` WHERE `lid`=%s"
    value=str(id)
    iud(qry,value)
    qry1="delete from login where lid=%s"
    value1=str(id)
    iud(qry1,value1)
    return '''<script>alert("deleted");window.location="/managestaff"</script>'''



@app.route("/managestudents")
@login_required
def managestudents():
    qry = "SELECT * FROM `course`"
    res = selectall(qry)
    return render_template("manage students.html",val=res)



@app.route("/managestudents1",methods=['get','post'])
@login_required
def managestudents1():
    button=request.form['Submit']
    if button=="SEARCH":
        course=request.form['select']
        print(course)
        semester=request.form['select2']
        print(semester)
        qry="SELECT * FROM `student` WHERE `semester`=%s AND `causeid`=%s"
        value=(semester,str(course))
        res=selectallnew(qry,value)
        print(res)
        qry="select * from course "
        res1 = selectall(qry)
        return render_template("manage students.html",val1=res,val=res1)
    else:

            qry = "SELECT * FROM `course`"
            res = selectall(qry)
            return render_template("add students.html", val=res)



@app.route("/deletestudent",methods=['get'])
@login_required
def deletestudent():
    id = request.args.get('id')
    qry="DELETE FROM `student` WHERE `loginid`=%s"
    value=str(id)
    iud(qry,value)
    qry1 = "delete from login where lid=%s"
    value1 = str(id)
    iud(qry1, value1)
    return '''<script>alert("deleted");window.location="/managestudents"</script>'''




@app.route("/editstudent",methods=['get'])
@login_required
def editstudent():
    id = request.args.get('id')
    session['cid'] = id
    qry = "SELECT * FROM `student` WHERE `loginid`=%s"
    val = str(id)
    res = selectonenew(qry, val)
    qry1 = "select * from course"
    res1= selectall(qry1)
    print(res1)
    return render_template("edit students.html",val=res,val1=res1)



@app.route("/updatestudent",methods=['post'])
@login_required
def updatestudent():
    id=session['cid']
    fname=request.form['textfield']
    lname=request.form['textfield2']
    gender=request.form['radiobutton']
    dob=request.form['textfield3']
    course=request.form['select']
    semester=request.form['select2']
    place=request.form['textfield4']
    email=request.form['textfield5']
    phone=request.form['textfield6']
    qry="UPDATE `student` SET `fname`=%s,`lname`=%s,`gender`=%s,`dob`=%s,`causeid`=%s,`semester`=%s,`place`=%s,`email`=%s,`phone`=%s WHERE `loginid`=%s"
    value = (fname,lname,gender,dob,course,semester,place,email,phone,str(id))
    iud(qry,value)
    return '''<script>alert("updated");window.location="/managestudents"</script>'''




@app.route("/managesubjects")
@login_required
def managesubjects():
    qry = "SELECT * FROM `subject`"
    res = selectall(qry)
    return render_template("manage subjects.html",val=res)



@app.route("/deletesubject",methods=['get'])
@login_required
def deletesubject():
    id=request.args.get('id')
    qry="DELETE FROM `subject` WHERE `subjectid`=%s"
    value=str(id)
    iud(qry,value)
    return '''<script>alert("deleted");window.location="/managesubjects"</script>'''



@app.route("/sendreply",methods=['get'])
@login_required
def sendreply():
    id=request.args.get('id')
    session['comid']=id
    return render_template("send reply.html")



@app.route("/sent",methods=['post'])
@login_required
def sent():
    cid=session['comid']
    reply=request.form['textarea']
    qry="UPDATE `complaints` SET `reply`=%s WHERE `complaints`.`id`=%s"
    value=(reply,str(cid))
    iud(qry,value)
    return '''<script>alert("reply  send");window.location="/adminhome"</script>'''



@app.route("/staffhome")
@login_required
def staffhome():
    return render_template("staff home.html")



@app.route("/viewallocatedsubjects")
@login_required
def viewallocatedsubjects():
    qry="SELECT `subject`.*,`subjectallocation`.* FROM `subject` JOIN `subjectallocation`ON `subjectallocation`.`subjectid`=`subject`.`subjectid`WHERE `subjectallocation`.`loginid`=%s"
    value=session['lid']
    res=selectallnew(qry,value)
    return render_template("view allocated subjects.html",val=res)




@app.route("/viewcomplaints")
@login_required
def viewcomplaints():
    qry="SELECT `complaints`.*,`student`.* FROM `student` JOIN `complaints` ON `complaints`.`userid`=`student`.`loginid` WHERE `complaints`.`reply`='pending'"
    res=selectall(qry)
    return render_template("view complaints.html",val=res)



@app.route("/viewexamdetails")
@login_required
def viewexamdetails():
    qry="SELECT * FROM`examdetails`"
    res=selectall(qry)
    return render_template("view examdetails.html",val=res)



@app.route("/viewfeedbacks")
@login_required
def viewfeedbacks():
    qry="SELECT `student`.*,`feedback`.* FROM `feedback` JOIN `student` ON `student`.loginid=`feedback`.loginid"
    res=selectall(qry)
    return render_template("view feedbacks.html",val=res)



@app.route("/viewreply")
@login_required
def viewreply():
    return render_template("view reply.html")




@app.route("/viewresult")
@login_required
def viewresult():
    qry="SELECT DISTINCT `attendexam`.`uid`,`student`.`fname`,`student`.`lname`,`examdetails`.`details`,SUM(`attendexam`.`mark`) FROM `attendexam` JOIN `student` ON `attendexam`.`uid`=`student`.`loginid` JOIN `questions` ON `attendexam`.`qid`=`questions`.`qid` JOIN `examdetails` ON `questions`.`eid`=`examdetails`.`examid` WHERE `examdetails`.`sid` IN(SELECT `subjectid` FROM `subjectallocation` WHERE `loginid`=%s) GROUP BY `examdetails`.`examid`,`student`.`loginid`"
    val=str(session['lid'])
    res=selectallnew(qry,val)
    return render_template("view result.html",val=res)

@app.route('/logout')
def logout():
    session.clear()
    return render_template("login.html")

app.run(debug=True)
