import cmd

from flask import *

from project.dbconnection import *
from project.test import checkans

app=Flask (__name__)

@app.route("/login",methods=['post'])
def log():
    uname=request.form['uname']
    print(uname)
    password=request.form['pass']
    print(password)
    qry="select * from login where username=%s and password=%s"
    val=(uname,password)
    s=selectonenew(qry,val)
    print(s)
    if s is None:
        return jsonify({'task': 'invalid'})
    else:
        id = s[0]
        return jsonify({'task': 'valid', "id": id})




@app.route('/viewsubjects', methods=['post'])
def viewsubjects():
        lid=request.form['lid']
        print(lid)
        qry = "SELECT `subject`.* FROM`subject` JOIN `course` ON `course`.`cid`=`subject`.`causeid` JOIN `student`ON `student`.`causeid`=`course`.`cid` WHERE `student`.`loginid`=%s"
        val=(lid)
        s = androidselectall(qry,val)
        print(s)
        return jsonify(s)



@app.route('/viewnotes1',methods=['post'])
def viewnotes1():
    subjectid=request.form['subjectid']
    qry="SELECT*FROM notes where subjectid=%s"
    val=(subjectid)
    s=androidselectall(qry,val)
    print(s)
    return jsonify(s)


@app.route('/chatwithstaff',methods=['post'])
def chatwithstaff():
    qry="select * from staff"
    s=androidselectallnew(qry)

    return jsonify(s)


@app.route('/chatinsert',methods=['post'])
def chatinsert():

    fid=request.form['from_id']
    tid=request.form['toid']
    msg=request.form['msg']
    qry="insert into chat values(null,%s,%s,curdate(),%s) "
    val=(fid,tid,msg)
    iud(qry,val)
    return ('success')



@app.route('/Viewchat',methods=['get','Post'])
def Viewchat():
    uid = request.form['uid']
    fid = request.form['fid']
    qry=("select * from chat where (fid=%s and tid=%s) or (fid=%s and tid=%s) order by date asc")

    val=(str(uid),str(fid),str(fid),str(uid ))
    s=androidselectall(qry,val)
    return jsonify(s)

@app.route('/sendfeedbacks',methods=['post'])
def sendfeedbacks():
        print(request.form)

        loginid= request.form['lid']
        feedback=request.form['feedback']
        print(loginid)
        print(feedback)

        qry="insert into feedback values(null,%s,%s,curdate())"
        val=(loginid,feedback)
        iud(qry,val)
        return jsonify({'task': 'success'})


@app.route('/sendcomplaints',methods=['post'])
def sendcomplaints():
    try:
        print(request.form)
        compt=request.form['complaint']
        print(compt)
        id=request.form['lid']
        qry="INSERT INTO `complaints`VALUES(null,%s,%s,curdate(),'pending')"
        val=(compt,id)
        iud(qry,val)
        return jsonify({'task': 'success'})
    except Exception as e:
        print(e)
        return jsonify ({'task': 'error'})

@app.route('/viewreply',methods=['post'])
def viewreply():
    userid = request.form['lid']
    print(userid)
    qry = "SELECT * FROM complaints where userid=%s"
    val = (userid)
    s = androidselectall(qry, val)
    print(s)
    return jsonify(s)





@app.route('/selectsubject',methods=['post'])
def selectsubject():

    qry = "SELECT * FROM `subject`"
    s = androidselectallnew(qry)
    return jsonify(s)


#
# @app.route('/viewquestions',methods=['post'])
# def viewquestions():
#     examid = request.form['subjecid']
#     qry = "SELECT * FROM `questions` WHERE eid=%s"
#     val = (examid)
#     s = androidselectall(qry, val)
#     return jsonify(s)



@app.route('/viewquestions',methods=['post'])
def viewquestions():
    subjecid = request.form['subjectid']
    print(subjecid)
    qry = "SELECT `questions`.* FROM `questions` JOIN `examdetails` ON `examdetails`.`examid`=`questions`.`eid` JOIN `subject` ON `subject`.`subjectid`=`examdetails`.`sid` WHERE `subject`.`subjectid`=%s"
    val = (subjecid)
    s = androidselectall(qry, val)
    print(s)
    return jsonify(s)






@app.route('/insertanswers',methods=['post'])
def insertanswers():
    qid=request.form['qid']
    uid=request.form['uid']
    answer=request.form['answer']
    mark=""
    qry="insert into attendexam values(null,%s,%s,%s)"
    val=(qid,uid,answer,mark)
    s=androidselectall(qry,val)
    return jsonify(s)
@app.route('/viewquestionpapers',methods=['post'])
def viewquestionpapers():
    qry="select * from questionpaper"
    s=androidselectallnew(qry)
    return jsonify(s)
@app.route("/viewresult",methods=['post'])
def viewresult():
    lid=request.form['lid']
    print(lid)
    qry="SELECT DISTINCT `attendexam`.`uid`,`student`.`fname`,`student`.`lname`,`examdetails`.`details`,SUM(`attendexam`.`mark`) AS mark FROM `attendexam` JOIN `student` ON `attendexam`.`uid`=`student`.`loginid` JOIN `questions` ON `attendexam`.`qid`=`questions`.`qid` JOIN `examdetails` ON `questions`.`eid`=`examdetails`.`examid` WHERE `examdetails`.`sid` IN(SELECT `subjectid` FROM `subjectallocation` WHERE `student`.`loginid`=%s) GROUP BY `examdetails`.`examid`,`student`.`loginid`"
    print(qry)
    val=(str(lid))
    s=androidselectall(qry,val)
    print(s)
    return jsonify(s)

@app.route("/selectexam")
def selectexam():
    qry="SELECT * FROM `examdetails`"
    s = androidselectallnew(qry)
    return jsonify(s)


@app.route("/attendexam",methods=['post'])
def attendexam():


    qid = request.form['qid']
    print(qid)


    uid = request.form['uid']
    ans = request.form['answer']
    qry2 = "select * from questions where qid =%s"
    val2 = (str(qid))
    s= selectonenew(qry2,val2)
    oans = s[3]
    mark = int(s[4])
    print(mark)

    sim = checkans(oans, ans)
    print(sim)
    omark = sim * mark
    print(omark)
    qry1 = "INSERT INTO attendexam VALUES(null,%s,%s,%s,%s)"
    val1 = (str(qid),str(uid),ans,omark)
    iud(qry1, val1)

    return jsonify({'task': 'success'})


if __name__=='__main__':
    app.run(host='0.0.0.0',port=5000)