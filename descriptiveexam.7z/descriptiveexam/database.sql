/*
SQLyog Community v13.0.1 (64 bit)
MySQL - 5.5.20-log : Database - descriptive_exam
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`descriptive_exam` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `descriptive_exam`;

/*Table structure for table `attendexam` */

DROP TABLE IF EXISTS `attendexam`;

CREATE TABLE `attendexam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `answer` text NOT NULL,
  `mark` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `attendexam` */

insert  into `attendexam`(`id`,`qid`,`uid`,`answer`,`mark`) values 
(1,1,4,'action opposit',63.2456);

/*Table structure for table `chat` */

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `date` date NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `chat` */

insert  into `chat`(`id`,`fid`,`tid`,`date`,`message`) values 
(1,4,2,'2021-12-04','hii miss');

/*Table structure for table `complaints` */

DROP TABLE IF EXISTS `complaints`;

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint` varchar(50) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` varchar(66) NOT NULL,
  `reply` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `complaints` */

insert  into `complaints`(`id`,`complaint`,`userid`,`date`,`reply`) values 
(1,'thought questions',4,'2021-12-04','pending');

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `course` */

insert  into `course`(`cid`,`cname`,`description`) values 
(1,'BSC','Bachelor of science.A BSc is a first degree in a  science subject.'),
(2,'BCA','Bachelor of computer appication.A three year undergraguate course.');

/*Table structure for table `examdetails` */

DROP TABLE IF EXISTS `examdetails`;

CREATE TABLE `examdetails` (
  `examid` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `sid` int(11) NOT NULL,
  `details` varchar(50) NOT NULL,
  PRIMARY KEY (`examid`),
  UNIQUE KEY `date` (`date`,`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `examdetails` */

insert  into `examdetails`(`examid`,`date`,`sid`,`details`) values 
(1,'2019-11-30',1,'LEVEL_0.png'),
(2,'2019-12-27',3,'LEVEL1.2.png');

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `feedbackid` int(11) NOT NULL AUTO_INCREMENT,
  `loginid` int(11) NOT NULL,
  `feedback` varchar(50) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`feedbackid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `feedback` */

insert  into `feedback`(`feedbackid`,`loginid`,`feedback`,`date`) values 
(1,4,'easy exam','2021-12-04');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`lid`,`username`,`password`),
  UNIQUE KEY `username` (`username`,`password`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`lid`,`username`,`password`,`type`) values 
(1,'archanarajkk@gmail.com','Archana0','admin'),
(2,'athi@gmail.com','Athi0123','staff'),
(3,'anu@gmail.com','Anu01234','staff'),
(4,'manchadi@gmail.com','Manchadi0','student');

/*Table structure for table `notes` */

DROP TABLE IF EXISTS `notes`;

CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notes` varchar(50) NOT NULL,
  `staffid` int(11) NOT NULL,
  `date` varchar(44) NOT NULL,
  `subjectid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `notes` */

insert  into `notes`(`id`,`notes`,`staffid`,`date`,`subjectid`) values 
(1,'LEVEL_0.png',2,'2021-12-04',1);

/*Table structure for table `questionpaper` */

DROP TABLE IF EXISTS `questionpaper`;

CREATE TABLE `questionpaper` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `questionpaper` varchar(20) NOT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `questionpaper` */

insert  into `questionpaper`(`qid`,`questionpaper`) values 
(1,'LEVEL_0.png');

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `eid` int(11) DEFAULT NULL,
  `question` text,
  `answer` text,
  `mark` int(11) DEFAULT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `questions` */

insert  into `questions`(`qid`,`eid`,`question`,`answer`,`mark`) values 
(1,1,'what is newton\'s third law??','every action there is an equal and opposit reaction',100);

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(40) NOT NULL,
  `place` varchar(40) NOT NULL,
  `qualification` varchar(40) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `lid` int(11) DEFAULT NULL,
  PRIMARY KEY (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`staffid`,`fname`,`lname`,`dob`,`gender`,`place`,`qualification`,`phone`,`email`,`lid`) values 
(1,'athi','bhaskaran','1998-02-07','FEMALE','kayanna','UG,PG,MPHIL,PHD',6238974200,'athi@gmail.com',2),
(2,'anu','sbb','1997-09-23','FEMALE','perambra','UG,PG,MPHIL,PHD',8086210874,'anu@gmail.com',3);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `studentid` int(11) NOT NULL AUTO_INCREMENT,
  `loginid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(49) NOT NULL,
  `causeid` int(11) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `place` varchar(70) NOT NULL,
  `semester` varchar(60) NOT NULL,
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`studentid`,`loginid`,`fname`,`lname`,`dob`,`gender`,`causeid`,`phone`,`email`,`place`,`semester`) values 
(1,4,'manchadi','bbc','2016-02-29','female',1,8090786756,'manchadi@gmail.com','kayanna','s1');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subjectid` int(11) NOT NULL AUTO_INCREMENT,
  `causeid` int(30) NOT NULL,
  `subjectcode` varchar(40) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  PRIMARY KEY (`subjectid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`subjectid`,`causeid`,`subjectcode`,`subject`,`semester`) values 
(1,1,'01','chemistry','s1'),
(2,1,'02','physics','s2'),
(3,2,'01','bca','s1');

/*Table structure for table `subjectallocation` */

DROP TABLE IF EXISTS `subjectallocation`;

CREATE TABLE `subjectallocation` (
  `allocationid` int(11) NOT NULL AUTO_INCREMENT,
  `subjectid` int(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  PRIMARY KEY (`allocationid`),
  UNIQUE KEY `subjectid` (`subjectid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `subjectallocation` */

insert  into `subjectallocation`(`allocationid`,`subjectid`,`loginid`) values 
(1,1,2),
(2,3,3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
